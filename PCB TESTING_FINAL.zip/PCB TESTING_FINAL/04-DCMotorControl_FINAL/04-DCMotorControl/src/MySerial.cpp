#include "MySerial.h"

extern double w1, w1_ref, MOT1_cmd; // Reference and command for the motor 1 - defined in MySetup.h
extern volatile long EncoderTick1;  // Encoder tick count for encoder 1 - defined in MySetup.h
extern unsigned long Serial_time;   // Time for serial communication - defined in MySetup.h

extern double w2, w2_ref, MOT2_cmd; // Reference and command for the motor 2 - defined in MySetup.h
extern volatile long EncoderTick2;  // Encoder tick count for encoder 2 - defined in MySetup.h


extern double w3, w3_ref, MOT3_cmd; // Reference and command for the motor 3 - defined in MySetup.h
extern volatile long EncoderTick3;  // Encoder tick count for encoder 3 - defined in MySetup.h


extern double w4, w4_ref, MOT4_cmd; // Reference and command for the motor 4 - defined in MySetup.h
extern volatile long EncoderTick4;  // Encoder tick count for encoder 4 - defined in MySetup.h


void SerialBegin() // Function to initialize the serial communication
{
    Serial.begin(115200);
    while (!Serial)
        ;
}

void SerialDataPrint() // Function to print the data to the Serial Monitor
{
    if (micros() - Serial_time >= 10000)
    {
        Serial_time = micros();
        Serial.print(">w1:");
        Serial.println(w1);
        Serial.print(">w2:");
        Serial.println(w2);
        Serial.print(">w3:");
        Serial.println(w3);
        Serial.print(">w4:");
        Serial.println(w4);
       
        Serial.print(">w1_ref:");
        Serial.println(w1_ref);
        Serial.print(">w2_ref:");
        Serial.println(w2_ref);
        Serial.print(">w3_ref:");
        Serial.println(w3_ref);
        Serial.print(">w4_ref:");
        Serial.println(w4_ref);
     
        Serial.print(">PWM1:");
        Serial.println(MOT1_cmd);
        Serial.print(">PWM2:");
        Serial.println(MOT2_cmd);
        Serial.print(">PWM3:");
        Serial.println(MOT3_cmd);
        Serial.print(">PWM4:");
        Serial.println(MOT4_cmd);
 
        Serial.print(">EncoderTick1:");
        Serial.println(EncoderTick1);
        Serial.print(">EncoderTick2:");
        Serial.println(EncoderTick2);
        Serial.print(">EncoderTick3:");
        Serial.println(EncoderTick3);
        Serial.print(">EncoderTick4:");
        Serial.println(EncoderTick4);

    }
}

// Function to write the data to the Serial Monitor
// Send q5 to rotate the motor 5rad/s (CCW)
// Send q-10 to rotate the motor -10rad/s (CW)
void SerialDataWrite() {
    static String received_chars;

    while (Serial.available())
    {
        char c = Serial.read();
        received_chars += c;

        if (c == '\n')
        {
            char cmd = received_chars[0];
            float value = received_chars.substring(1).toFloat();

            switch(cmd)
            {
                case 'o': w1_ref = value; break;  
                case 'a': w2_ref = value; break;
                case 'h': w3_ref = value; break;
                case 'f': w4_ref = value; break;
            }
            received_chars = "";
        }
    }
}
// o = m2, a = m4, h = m1, f= m3 
