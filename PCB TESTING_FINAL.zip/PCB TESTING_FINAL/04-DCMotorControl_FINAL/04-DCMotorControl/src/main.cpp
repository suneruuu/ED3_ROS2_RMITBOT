#include <Arduino.h> // Arduino library for basic functions

// The follwing libraries are custom libraries.
// Header files (.h) contains function declarations, and are located in the include folder
// Sources (.cpp) contains function definitions, and are located in the src folder
#include "MySetup.h"      // Pin and variable definitions
#include "MyEncoder.h"    // Library for the encoder
#include "MyMotor.h"      // Library for the motor
#include "MyController.h" // Library for the controller
#include "MySerial.h"     // Library for the controller

Encoder encoder1(ENC1_A, ENC1_B);                // Create an instance of the Encoder class
Motor motor1(MOT1_A, MOT1_B, PWM1_A, PWM1_B);    // Create an instance of the Motor class
Controller controller1(&w1, &MOT1_cmd, &w1_ref); // Create an instance of the Controller class

Encoder encoder2(ENC1_C, ENC1_D);                // Create an instance of the Encoder class
Motor motor2(MOT1_C, MOT1_D, PWM1_C, PWM1_D);    // Create an instance of the Motor class
Controller controller2(&w2, &MOT2_cmd, &w2_ref); // Create an instance of the Controller class

Encoder encoder3(ENC1_E, ENC1_F);                // Create an instance of the Encoder class
Motor motor3(MOT1_E, MOT1_F, PWM1_E, PWM1_F);    // Create an instance of the Motor class
Controller controller3(&w3, &MOT3_cmd, &w3_ref); // Create an instance of the Controller class

Encoder encoder4(ENC1_G, ENC1_H);                // Create an instance of the Encoder class
Motor motor4(MOT1_G, MOT1_H, PWM1_G, PWM1_H);    // Create an instance of the Motor class
Controller controller4(&w4, &MOT4_cmd, &w4_ref); // Create an instance of the Controller class

//==============================================
// Arduino Setup
//==============================================
void setup()
{
  encoder1.begin();    // Initialize the encoder
  motor1.begin();      // Initialize the motor
  controller1.begin(); // Initialize the controller

  encoder2.begin();    // Initialize the encoder
  motor2.begin();      // Initialize the motor
  controller2.begin(); // Initialize the controller

  encoder3.begin();    // Initialize the encoder
  motor3.begin();      // Initialize the motor
  controller3.begin(); // Initialize the controller

  encoder4.begin();    // Initialize the encoder
  motor4.begin();      // Initialize the motor
  controller4.begin(); // Initialize the controller
  SerialBegin();       // Initialize the serial communication
}

void loop()
{
  EncoderTick1 = encoder1.getCount(); // Get the encoder count
  w1 = encoder1.getVelocity();        // Get the velocity from the encoder
  controller1.compute();              // Compute the PID control output
  motor1.send_pwm(MOT1_cmd);          // Send the PWM command to the motor

  EncoderTick2 = encoder2.getCount(); // Get the encoder count
  w2 = encoder2.getVelocity();        // Get the velocity from the encoder
  controller2.compute();              // Compute the PID control output
  motor2.send_pwm(MOT2_cmd);          // Send the PWM command to the motor

   EncoderTick3 = encoder3.getCount(); // Get the encoder count
  w3 = encoder3.getVelocity();        // Get the velocity from the encoder
  controller3.compute();              // Compute the PID control output
  motor3.send_pwm(MOT3_cmd);          // Send the PWM command to the motor

   EncoderTick4 = encoder4.getCount(); // Get the encoder count
  w4 = encoder4.getVelocity();        // Get the velocity from the encoder
  controller4.compute();              // Compute the PID control output
  motor4.send_pwm(MOT4_cmd);          // Send the PWM command to the motor


  SerialDataPrint();                  // Print the data to the Serial Monitor

  SerialDataWrite();                  // Write the data to the Serial Monitor
 
}
